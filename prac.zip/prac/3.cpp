// WAP to find the largest of 3 numbers using conditional operators
#include <stdio.h>


int main() {
    int a,b,c;
    int max;

    printf("Enter three numbers:\n");
    scanf("%d %d %d", &a, &b, &c);

    if      (a>b and a>c)    {max = a;}
    else if (b>a and b>c)    {max = b;}
    else if (c>a and c>b)    {max = c;}

    printf("\nAmong those 3 numbers, %d is the greatest number", max);

    printf("\n");
}